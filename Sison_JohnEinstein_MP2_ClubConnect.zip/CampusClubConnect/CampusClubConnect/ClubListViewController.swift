import UIKit

final class ClubListViewController: UITableViewController {
    private var clubs: [Club] = []; private var selectedClub: Club?
    override func viewDidLoad() { super.viewDidLoad(); title = "Clubs"; tableView.register(ClubCell.self, forCellReuseIdentifier: "ClubCell"); navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addClub)); ClubStore.seedIfNeeded(); loadClubs() }
    private func loadClubs() { let request = Club.fetchRequest(); request.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]; clubs = (try? ClubStore.context.fetch(request)) ?? []; tableView.reloadData() }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { clubs.count }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell { let cell = tableView.dequeueReusableCell(withIdentifier: "ClubCell", for: indexPath) as! ClubCell; cell.configure(with: clubs[indexPath.row]); cell.accessoryType = .disclosureIndicator; return cell }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) { selectedClub = clubs[indexPath.row]; performSegue(withIdentifier: "ShowClubDetailSegue", sender: self); tableView.deselectRow(at: indexPath, animated: true) }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) { (segue.destination as? ClubDetailViewController)?.club = selectedClub }
    @objc private func addClub() { let alert = UIAlertController(title: "Add Club", message: "Create a club record saved to Core Data.", preferredStyle: .alert); alert.addTextField { $0.placeholder = "Club name" }; alert.addTextField { $0.placeholder = "Category" }; alert.addAction(UIAlertAction(title: "Cancel", style: .cancel)); alert.addAction(UIAlertAction(title: "Save", style: .default) { [weak self, weak alert] _ in guard let self, let alert, let name = alert.textFields?[0].text, !name.isEmpty, let category = alert.textFields?[1].text, !category.isEmpty else { return }; let club = Club(context: ClubStore.context); club.name = name; club.category = category; club.iconName = "star.fill"; ClubStore.save(); self.loadClubs() }); present(alert, animated: true) }
}
