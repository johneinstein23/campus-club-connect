import UIKit
import CoreData

private enum PreferenceKey {
    static let name = "studentName"
    static let reminders = "notificationsEnabled"
    static let role = "selectedRoleIndex"
}

@objc(Club)
final class Club: NSManagedObject {
    @NSManaged var name: String?
    @NSManaged var category: String?
    @NSManaged var iconName: String?
}

extension Club { @nonobjc class func fetchRequest() -> NSFetchRequest<Club> { NSFetchRequest(entityName: "Club") } }

enum ClubStore {
    static let roles = ["Student", "Faculty"]
    static var defaults: UserDefaults { .standard }
    static var context: NSManagedObjectContext { (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext }

    static func seedIfNeeded() {
        let request = Club.fetchRequest()
        guard (try? context.count(for: request)) == 0 else { return }
        [("Robotics Club", "STEM", "gearshape.2.fill"), ("Photography Club", "Arts", "camera.fill"), ("Debate Society", "Academic", "bubble.left.and.bubble.right.fill"), ("Hiking Club", "Outdoors", "figure.hiking"), ("Chess Club", "Games", "checkerboard.rectangle")].forEach { name, category, icon in
            let club = Club(context: context); club.name = name; club.category = category; club.iconName = icon
        }
        save()
    }

    static func save() { if context.hasChanges { try? context.save() } }
    static func savePreferences(name: String, reminders: Bool, roleIndex: Int) { defaults.set(name, forKey: PreferenceKey.name); defaults.set(reminders, forKey: PreferenceKey.reminders); defaults.set(roleIndex, forKey: PreferenceKey.role) }
    static func clearPreferences() { defaults.removeObject(forKey: PreferenceKey.name); defaults.removeObject(forKey: PreferenceKey.reminders); defaults.removeObject(forKey: PreferenceKey.role) }
    static var savedName: String { defaults.string(forKey: PreferenceKey.name) ?? "" }
    static var savedReminders: Bool { defaults.bool(forKey: PreferenceKey.reminders) }
    static var savedRole: Int { defaults.integer(forKey: PreferenceKey.role) }
}
