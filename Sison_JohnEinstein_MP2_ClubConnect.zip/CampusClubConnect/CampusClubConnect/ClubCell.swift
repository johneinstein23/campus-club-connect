import UIKit

final class ClubCell: UITableViewCell {
    private let iconView = UIImageView(); private let nameLabel = UILabel(); private let categoryLabel = UILabel()
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) { super.init(style: style, reuseIdentifier: reuseIdentifier); configureLayout() }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    private func configureLayout() { iconView.tintColor = .systemBlue; iconView.backgroundColor = .secondarySystemFill; iconView.layer.cornerRadius = 22; iconView.clipsToBounds = true; iconView.contentMode = .center; nameLabel.font = .preferredFont(forTextStyle: .headline); categoryLabel.font = .preferredFont(forTextStyle: .caption1); categoryLabel.textColor = .secondaryLabel; let labels = UIStackView(arrangedSubviews: [nameLabel, categoryLabel]); labels.axis = .vertical; labels.spacing = 3; let row = UIStackView(arrangedSubviews: [iconView, labels]); row.spacing = 12; row.alignment = .center; row.translatesAutoresizingMaskIntoConstraints = false; contentView.addSubview(row); NSLayoutConstraint.activate([row.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16), row.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16), row.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12), row.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -12), iconView.widthAnchor.constraint(equalToConstant: 44), iconView.heightAnchor.constraint(equalToConstant: 44)]) }
    func configure(with club: Club) { nameLabel.text = club.name; categoryLabel.text = club.category; iconView.image = UIImage(systemName: club.iconName ?? "person.3.fill") }
}
