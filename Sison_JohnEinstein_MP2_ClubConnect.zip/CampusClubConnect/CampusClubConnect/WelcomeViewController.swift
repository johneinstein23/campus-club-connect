import UIKit

final class WelcomeViewController: UIViewController {
    private let nameField = UITextField(); private let reminderSwitch = UISwitch(); private let roleControl = UISegmentedControl(items: ClubStore.roles)
    override func viewDidLoad() { super.viewDidLoad(); title = "Campus Club Connect"; view.backgroundColor = .systemGroupedBackground; buildUI(); restore() }
    private func buildUI() {
        let stack = UIStackView(); stack.axis = .vertical; stack.spacing = 18; stack.translatesAutoresizingMaskIntoConstraints = false
        let titleLabel = UILabel(); titleLabel.text = "Find your people"; titleLabel.font = .preferredFont(forTextStyle: .largeTitle)
        let intro = UILabel(); intro.text = "Explore clubs, meet classmates, and keep your preferences saved."; intro.numberOfLines = 0; intro.textColor = .secondaryLabel
        stack.addArrangedSubview(titleLabel); stack.addArrangedSubview(intro); stack.addArrangedSubview(field("Your name", nameField)); stack.addArrangedSubview(toggle()); stack.addArrangedSubview(field("Role", roleControl))
        let join = UIButton(type: .system); join.setTitle("Join Campus Clubs", for: .normal); join.backgroundColor = .systemBlue; join.tintColor = .white; join.layer.cornerRadius = 12; join.heightAnchor.constraint(equalToConstant: 52).isActive = true; join.addTarget(self, action: #selector(joinTapped), for: .touchUpInside); stack.addArrangedSubview(join)
        let reset = UIButton(type: .system); reset.setTitle("Reset saved preferences", for: .normal); reset.addTarget(self, action: #selector(resetTapped), for: .touchUpInside); stack.addArrangedSubview(reset)
        view.addSubview(stack); NSLayoutConstraint.activate([stack.leadingAnchor.constraint(equalTo: view.layoutMarginsGuide.leadingAnchor), stack.trailingAnchor.constraint(equalTo: view.layoutMarginsGuide.trailingAnchor), stack.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -20)])
    }
    private func field(_ labelText: String, _ control: UIView) -> UIView { let label = UILabel(); label.text = labelText; label.textColor = .secondaryLabel; let s = UIStackView(arrangedSubviews: [label, control]); s.axis = .vertical; s.spacing = 7; return s }
    private func toggle() -> UIView { let label = UILabel(); label.text = "Send club reminders"; let row = UIStackView(arrangedSubviews: [label, reminderSwitch]); row.alignment = .center; return row }
    private func restore() { nameField.text = ClubStore.savedName; reminderSwitch.isOn = ClubStore.savedReminders; roleControl.selectedSegmentIndex = ClubStore.savedRole }
    @objc private func joinTapped() { ClubStore.savePreferences(name: nameField.text ?? "", reminders: reminderSwitch.isOn, roleIndex: roleControl.selectedSegmentIndex); navigationController?.pushViewController(ClubListViewController(), animated: true) }
    @objc private func resetTapped() { ClubStore.clearPreferences(); restore(); let alert = UIAlertController(title: "Preferences reset", message: "The welcome screen is back to its safe defaults.", preferredStyle: .alert); alert.addAction(UIAlertAction(title: "OK", style: .default)); present(alert, animated: true) }
}
