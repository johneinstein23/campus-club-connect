# Campus Club Connect — Machine Problem 2

Student: John Einstein Sison

This iOS UIKit project extends the ClubConnect idea with a custom club directory, Core Data persistence, UserDefaults welcome preferences, row selection, and adding new clubs.

## Run

Open `CampusClubConnect.xcodeproj` in Xcode 15 or later and run on an iOS 15+ Simulator.

## Verification

Enter `John Einstein Sison`, enable reminders, choose a role, and tap **Join Campus Clubs**. The welcome values are saved with UserDefaults. The directory is seeded once from Core Data, rows use `ClubCell`, tapping a row opens the confirmation/detail screen, and **+** inserts a new club that survives relaunch.

## Reflection

`UITableView` and `UITableViewDataSource` make the list reusable because the controller asks for the current count and configures only the visible rows. The custom `ClubCell` keeps the row layout in one place instead of repeating view setup in the controller. Core Data is a better fit than a fixed array because records can be fetched, inserted, and saved across launches. UserDefaults remains appropriate for the small welcome-screen values, similar to SharedPreferences in Mobile Application Development 1.

The `Preview/` folder provides a browser preview of the same student-facing flow for environments without Xcode.
